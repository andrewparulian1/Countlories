type FoodCategory = {
  id: number
  name: string
  color: string
}

export type { FoodCategory }
