type Form = {
  fieldId: string
  name: string
}

export type { Form }
