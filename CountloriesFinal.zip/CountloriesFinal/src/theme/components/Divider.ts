const Divider = {
  sizes: {
    md: {
      borderBottomWidth: '8px',
    },
    lg: {
      borderBottomWidth: '12px',
    },
  },
}

export default Divider
