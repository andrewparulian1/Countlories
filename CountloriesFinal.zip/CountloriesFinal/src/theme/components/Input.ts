const Input = {
  defaultProps: {
    focusBorderColor: 'teal.400',
  },
}

export default Input
